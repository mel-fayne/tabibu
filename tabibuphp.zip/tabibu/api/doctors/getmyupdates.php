<?php

include '../config/config.php';

$doctorid = $_POST["doctorid"];
//$doctorid = "1";
$status ="Unseen";

//first check if doctor has any updates on app 

$query = "SELECT DISTINCT * FROM updatelist WHERE doctorid = '".$doctorid."'";
$res = mysqli_query($conn, $query);
$count = mysqli_num_rows($res);

if ($count >= 1){
    $queryMyupdts = "SELECT DISTINCT * FROM updatelist WHERE doctorid = '".$doctorid."' AND status = '".$status."'";
    $result = array();
    $queryResult = mysqli_query($conn, $queryMyupdts);
    $unseencount = mysqli_num_rows($queryResult);
    if ($unseencount >=1){

    while($row = mysqli_fetch_assoc($queryResult)){
    array_push($result, $row);
    }
    echo json_encode($result);
    }else{
        echo json_encode("all updates seen");
    }
}else{
    echo json_encode("no updates on app");
}
?>
