<?php

include '../config/config.php';

$dr_id = $_POST["dr_id"];
//$dr_id = "1";
$status ="Closed";

//first check if doctor has any patients on app 

$query = "SELECT DISTINCT * FROM patientlist WHERE dr_id = '".$dr_id."'";
$res = mysqli_query($conn, $query);
$count = mysqli_num_rows($res);

if ($count >= 1){
    $queryMypts = "SELECT DISTINCT * FROM patientlist WHERE dr_id = '".$dr_id."' AND status = '".$status."'";
    $result = array();
    $queryResult = mysqli_query($conn, $queryMypts);
    $closedcount = mysqli_num_rows($queryResult);
    if ($closedcount >=1){

    while($row = mysqli_fetch_assoc($queryResult)){
    array_push($result, $row);
    }
    echo json_encode($result);
    }else{
        echo json_encode("all cases open");
    }
}else{
    echo json_encode("no cases on app");
}
?>
