<?php

require_once("../config/config.php");

$userid = $_POST["userid"];

//first check if account exists

$query = "SELECT * FROM doctors WHERE userid = '".$userid."'";
$res = mysqli_query($conn, $query);
$data = mysqli_fetch_array($res);
$count = mysqli_num_rows($res);

// data[0] = docid, data[1] = hospital, data[2] = specialty, data[3] = practiceyears
// data[4] = about, data [5] = liscenece, data[6] = days, data[7] = time, data[8] = userid
if ($count == 1){
    echo json_encode([$data['0'],$data['1'],$data['2'],$data['3'],$data['4'],$data['5'],$data['6'],$data['7']]);
}else{
    echo json_encode("error");
}
?>