<?php

include '../config/config.php';

$query = "SELECT * FROM doctorusers  ORDER BY name ASC";
$res = mysqli_query($conn, $query);
$count = mysqli_num_rows($res);

if ($count >= 1){

    $result = array();
    $queryResult = mysqli_query($conn, $query);
    while($row = mysqli_fetch_assoc($queryResult)){

    array_push($result, $row);
    }
    echo json_encode($result);
}else{
    echo json_encode("no doctors");
}
?>
