<?php

include '../config/config.php';

$doctorid = $_POST["doctorid"];
//$doctorid = "5";
$status ="Done";

//first check if doctor has any appt on app 

$query = "SELECT DISTINCT * FROM appointmentlist WHERE doctorid = '".$doctorid."'";
$res = mysqli_query($conn, $query);
$count = mysqli_num_rows($res);

if ($count >= 1){
    $queryMypts = "SELECT DISTINCT * FROM appointmentlist WHERE doctorid = '".$doctorid."' AND status = '".$status."'";
    $result = array();
    $queryResult = mysqli_query($conn, $queryMypts);
    $donecount = mysqli_num_rows($queryResult);
    if ($donecount >=1){

    while($row = mysqli_fetch_assoc($queryResult)){
    array_push($result, $row);
    }
    echo json_encode($result);
    }else{
        echo json_encode("all appt conf or unconf");
    }
}else{
    echo json_encode("no appt on app");
}
?>
