<?php

require_once("../config/config.php");

$doctorid = $_POST["doctorid"];
//$doctorid = "1";

//first check if account exists

$query = "SELECT * FROM doctorusers WHERE doctorid = '".$doctorid."'";
$res = mysqli_query($conn, $query);
$data = mysqli_fetch_array($res);
$count = mysqli_num_rows($res);

//data[1] = name, data[2] = email, data[3] = county data[4] = drid
//data [5] = hospital, data[6] = specialty, data[7] = practiceyears
//data[8] = about, data[9] = liscenece, data[10] = days
//data[11] = time
if ($count == 1){
   // echo json_encode([$data['1'],$data['2'],$data['3'],$data['4'],$data['5'],$data['6'],$data['7'],$data['8'],$data['9'],$data['10'],$data['11']]);
   echo json_encode([$data['1'],$data['5'],$data['6'],$data['7'],$data['8'],$data['9'],$data['10'],$data['11']]);
}else{
    echo json_encode("error");
}
?>