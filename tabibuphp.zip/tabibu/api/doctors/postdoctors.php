<?php

require_once("../config/config.php");

$hospital = $_POST["hospital"];
$specialty = $_POST["specialty"];
$practiceyrs = $_POST["practiceyrs"];
$about = $_POST["about"];
$liscence = $_POST["liscence"];
$days = $_POST["days"];
$time = $_POST["time"];
$userid = $_POST["userid"];

//check if doctor with same user id already exists

$query = "SELECT * FROM doctors WHERE userid LIKE '$userid'";
$res = mysqli_query($conn, $query);
$data = mysqli_fetch_array($res);

if($data[0] >= 1) {
    //account exists
    echo json_encode("doctor user exists");
}else{
    //add new doctor details
    $query = "INSERT INTO doctors (doctorid,hospital,specialty,practiceyrs,about,liscence,days,time,userid) VALUES (null, '$hospital', '$specialty', '$practiceyrs', '$about', '$liscence', '$days', '$time', '$userid')";
    $res = mysqli_query($conn, $query);

    if($res){
        
        $query = "SELECT * FROM doctors WHERE userid = '".$userid."'";
        $res = mysqli_query($conn, $query);
        $data = mysqli_fetch_array($res);
        $count = mysqli_num_rows($res);

        if ($count == 1){
            echo json_encode([$data['0'],$data['1'],$data['2'],$data['3'],$data['4'],$data['5'],$data['6'],$data['7']]);
        }else{
            //wrong credentials or account inexistent
            echo json_encode("couldn't get data");
        }
    }else{
        echo json_encode("error");
    }
}
?>