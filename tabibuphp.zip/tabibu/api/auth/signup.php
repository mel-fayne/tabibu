<?php

require_once("../config/config.php");

$name = $_POST["name"];
$email = $_POST["email"];
$county = $_POST["county"];
$pass = $_POST["pass"];
$role = $_POST["role"];

//check if account already exists

$query = "SELECT * FROM users WHERE email LIKE '$email'";
$res = mysqli_query($conn, $query);
$data = mysqli_fetch_array($res);

if($data[0] >= 1) {
    //account exists
    echo json_encode("account already exists");
}else{
    //create new user account
    $query = "INSERT INTO users (userid,name,email,county,pass,role) VALUES (null, '$name', '$email', '$county', '$pass', '$role')";
    $res = mysqli_query($conn, $query);

    if($res){
        // data[0] = id
        
        $query = "SELECT * FROM users WHERE email = '".$email."' AND pass = '".$pass."'";
        $res = mysqli_query($conn, $query);
        $data = mysqli_fetch_array($res);
        $count = mysqli_num_rows($res);

        // data[0] = id, data[1] = name, data[2] = email ... data[4] = pass ...data[5] = role
        if ($count == 1){
            echo json_encode([$data['0'],$data['1'],$data['5']]);
        }else{
            //wrong credentials or account inexistent
            echo json_encode("error");
        }
    }else{
        echo json_encode("error");
    }
}
?>