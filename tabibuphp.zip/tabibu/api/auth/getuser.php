<?php

require_once("../config/config.php");

$userid = $_POST["userid"];

//first check if account exists

$query = "SELECT * FROM users WHERE userid = '".$userid."'";
$res = mysqli_query($conn, $query);
$data = mysqli_fetch_array($res);
$count = mysqli_num_rows($res);

// data[0] = id, data[1] = name, data[2] = email, data[3] = county, data[4] = pass data[5] = role
if ($count == 1){
    echo json_encode([$data['1'],$data['2'],$data['3']]);
}else{
    echo json_encode("error");
}
?>