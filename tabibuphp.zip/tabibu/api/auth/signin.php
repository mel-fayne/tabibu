<?php

require_once("../config/config.php");

$email = $_POST["email"];
$pass = $_POST["pass"];

//first check if account exists

$query = "SELECT * FROM users WHERE email = '".$email."' AND pass = '".$pass."'";
$res = mysqli_query($conn, $query);
$data = mysqli_fetch_array($res);
$count = mysqli_num_rows($res);

// data[0] = id, data[1] = name, data[2] = email ... data[4] = pass ...data[5] = role
if ($count == 1){
    /* $resarr =array();
    array_push($resarr,array("userid"=>$data['0'],"name"=>$data['1'],"role"=>$data['5']));
    echo json_encode(array($resarr)); */
    echo json_encode([$data['0'],$data['1'],$data['5']]);
}else{
    //wrong credentials or account inexistent
    echo json_encode("error");
}
?>