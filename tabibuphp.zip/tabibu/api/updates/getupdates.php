<?php

include '../config/config.php';

$patientid = $_POST["patientid"];

//first check if account exists
$query = "SELECT * FROM updatelist WHERE patientid = '".$patientid."'";
$res = mysqli_query($conn, $query);
$count = mysqli_num_rows($res);

if ($count >= 1){
    //if the patient has updates...
    $queryUpdate = "SELECT * FROM updatelist WHERE patientid = '".$patientid."'";
    $result = array();
    $queryResult = mysqli_query($conn, $queryUpdate);
    while($row = mysqli_fetch_assoc($queryResult)){
  //  $result = $row;
    array_push($result, $row);
    }
    echo json_encode($result);
}else{
    echo json_encode("no update");
}
?>
