<?php

require_once("../config/config.php");

$patientid = $_POST["patientid"];
$doctorid = $_POST["doctorid"];
$date = $_POST["date"];
$feel = $_POST["feel"];
$partache = $_POST["partache"];
$painrate = $_POST["painrate"];
$newsymptom = $_POST["newsymptom"];
$sideeffect = $_POST["sideeffect"];
$medintake = $_POST["medintake"];
$additional = $_POST["additional"];
$status = $_POST["status"];

    $query = "INSERT INTO updates (updateid,patientid,doctorid,date,feel,partache,painrate,newsymptom,sideeffect,medintake,additional,status) VALUES (null, '$patientid', '$doctorid', '$date', '$feel', '$partache', '$painrate', '$newsymptom', '$sideeffect', '$medintake', '$additional', '$status')";
    $res = mysqli_query($conn, $query);

    if($res){
            echo json_encode("success");
    }else{
        echo json_encode("error");
    }

?>
