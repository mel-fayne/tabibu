<?php

require_once("../config/config.php");

$updateid = $_POST["updateid"];
//updateid = "3";
$status = "Seen";


    $query = "UPDATE updates set status='".$status."' WHERE updateid='".$updateid."'";
    $res = mysqli_query($conn, $query);

    if($res){
            echo json_encode("success");
    }else{
        echo json_encode("error");
    }

?>