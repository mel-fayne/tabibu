<?php

include '../config/config.php';

$updateid = $_POST["updateid"];

//first check if record exists
$query = "SELECT * FROM updatelist WHERE updateid = '".$updateid."'";
$res = mysqli_query($conn, $query);
$data = mysqli_fetch_array($res);
$count = mysqli_num_rows($res);

// data[0] = updateid, data[1] = patientid, data[2] = doctorid, data[3] = date
//data [4] = feel, data[5] = partache, data [6] = painrate, data[7] = newsysmptom
//data[8] = sideefect data[9] = medintake, data[10] = additional

if ($count == 1){
    echo json_encode([$data['0'],$data['1'],$data['2'],$data['3'],$data['4'],$data['5'],$data['6'],$data['7'],$data['8'],$data['9'],$data['10'],$data['11'],$data['12'],$data['13']]);
}else{
    echo json_encode("error");
}
?>
