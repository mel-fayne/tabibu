<?php

    $host = "localhost";
    $user = "root";
    $password = "";
    $db_name = "tabibu";


    $conn = mysqli_connect($host, $user, $password, $db_name);

    /* if(!$conn){
        echo "Could not connect to Tabibu Databse";
    }
    else{
        echo "Successfully conncted to Tabibu Database\n";
    }
 */
?>