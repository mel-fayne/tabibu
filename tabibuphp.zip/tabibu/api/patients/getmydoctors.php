<?php

include '../config/config.php';

$pt_id = $_POST["pt_id"];
//$pt_id = "1";

//first check if patient has any doctors on app 

$query = "SELECT DISTINCT * FROM doctorlist WHERE pt_id = '".$pt_id."'";
$res = mysqli_query($conn, $query);
$count = mysqli_num_rows($res);

if ($count >= 1){
    $queryMydrs = "SELECT DISTINCT * FROM doctorlist WHERE pt_id = '".$pt_id."'";
    $result = array();
    $queryResult = mysqli_query($conn, $queryMydrs);
    while($row = mysqli_fetch_assoc($queryResult)){

    array_push($result, $row);
    }
    echo json_encode($result);
}else{
    echo json_encode("no doctors on app");
}
?>
