<?php

include '../config/config.php';

$patientid = $_POST["patientid"];
//$patientid = "1";
$status ="Confirmed";

//first check if patient has any appt on app 

$query = "SELECT DISTINCT * FROM appointmentlist WHERE patientid = '".$patientid."'";
$res = mysqli_query($conn, $query);
$count = mysqli_num_rows($res);

if ($count >= 1){
    $queryMypts = "SELECT DISTINCT * FROM appointmentlist WHERE patientid = '".$patientid."' AND status = '".$status."'";
    $result = array();
    $queryResult = mysqli_query($conn, $queryMypts);
    $unconfcount = mysqli_num_rows($queryResult);
    if ($unconfcount >=1){

    while($row = mysqli_fetch_assoc($queryResult)){
    array_push($result, $row);
    }
    echo json_encode($result);
    }else{
        echo json_encode("all appt done or conf");
    }
}else{
    echo json_encode("no appt on app");
}
?>
