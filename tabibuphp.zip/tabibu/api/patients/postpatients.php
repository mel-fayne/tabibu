<?php

require_once("../config/config.php");

$dob = $_POST["dob"];
$preexisting_cond = $_POST["preexisting_cond"];
$blood_type = $_POST["blood_type"];
$payment_mode = $_POST["payment_mode"];
$userid = $_POST["userid"];

//check if patient with same user id already exists

$query = "SELECT * FROM patient WHERE userid LIKE '$userid'";
$res = mysqli_query($conn, $query);
$data = mysqli_fetch_array($res);

if($data[0] >= 1) {
    //account exists
    echo json_encode("patient user exists");
}else{
    //add new patient details
    $query = "INSERT INTO patient (patient_id,dob,preexisting_cond,blood_type,payment_mode,userid) VALUES (null, '$dob', '$preexisting_cond', '$blood_type', '$payment_mode', '$userid')";
    $res = mysqli_query($conn, $query);

    if($res){
        $query = "SELECT * FROM patient WHERE userid = '".$userid."'";
        $res = mysqli_query($conn, $query);
        $data = mysqli_fetch_array($res);
        $count = mysqli_num_rows($res);

        if ($count == 1){
        // data[0] = ptid, data[1] = dob, data[2] = preexisting_cond,
        // data[3] = bloodtype, data [4] = paymode, data[5] = userid
            echo json_encode([$data['0'],$data['1'],$data['2'],$data['3'],$data['4'],$data['5']]);
        }else{
            echo json_encode("error");
        }
    }else{
        echo json_encode("error");
    }
}
?>