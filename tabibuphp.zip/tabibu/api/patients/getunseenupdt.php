<?php

include '../config/config.php';

$patientid = $_POST["patientid"];
//$patientid = "1";
$status ="Unseen";

//first check if patient has any updates on app 

$query = "SELECT DISTINCT * FROM updatelist WHERE patientid = '".$patientid."'";
$res = mysqli_query($conn, $query);
$count = mysqli_num_rows($res);

if ($count >= 1){
    $queryMyupdts = "SELECT DISTINCT * FROM updatelist WHERE patientid = '".$patientid."' AND status = '".$status."'";
    $result = array();
    $queryResult = mysqli_query($conn, $queryMyupdts);
    $seencount = mysqli_num_rows($queryResult);
    if ($seencount >=1){

    while($row = mysqli_fetch_assoc($queryResult)){
    array_push($result, $row);
    }
    echo json_encode($result);
    }else{
        echo json_encode("all updates unseen");
    }
}else{
    echo json_encode("no updates on app");
}
?>
