<?php

require_once("../config/config.php");

$userid = $_POST["userid"];

//first check if account exists

$query = "SELECT * FROM patient WHERE userid = '".$userid."'";
$res = mysqli_query($conn, $query);
$data = mysqli_fetch_array($res);
$count = mysqli_num_rows($res);

// data[0] = ptid, data[1] = condtype, data[2] = condname, data[3] = bloodtype
// data[4] = paymode, data [5] = userid
if ($count == 1){
    echo json_encode([$data['0'],$data['1'],$data['2'],$data['3'],$data['4']]);
}else{
    echo json_encode("error");
}
?>