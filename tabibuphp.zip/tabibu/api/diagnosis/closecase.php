<?php

require_once("../config/config.php");

$recordid = $_POST["recordid"];
//$recordid = "1";
$status = "Closed";


    $query = "UPDATE medrecords set status='".$status."' WHERE recordid='".$recordid."'";
    $res = mysqli_query($conn, $query);

    if($res){
            echo json_encode("success");
    }else{
        echo json_encode("error");
    }

?>