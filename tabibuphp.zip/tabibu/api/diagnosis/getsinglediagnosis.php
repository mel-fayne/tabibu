<?php

include '../config/config.php';

$recordid = $_POST["recordid"];

//first check if record exists
$query = "SELECT * FROM fulldiagnosis WHERE recordid = '".$recordid."'";
$res = mysqli_query($conn, $query);
$data = mysqli_fetch_array($res);
$count = mysqli_num_rows($res);

// data[0] = recordid, data[1] = disease, data[2] = desc, data[3] = date
//data [4] = weight, data[5] = temp, data [6] = pulse, data[7] = pressure, 
//data[8] = symptoms, data[9] = medicine, data[10] = prescription
//data[11] = treatmentinfo, data[12] = dr_id, data[13] = pt_id
//data[14] = ptname data[15] = drname, date[16] = hospital, data[17] = status
if ($count == 1){
    echo json_encode([$data['0'],$data['1'],$data['2'],$data['3'],$data['4'],$data['5'],$data['6'],$data['7'],$data['8'],$data['9'],$data['10'],$data['11'],$data['12'],$data['13'],$data['14'],$data['15'],$data['16'],$data['17']]);
}else{
    echo json_encode("error");
}
?>
