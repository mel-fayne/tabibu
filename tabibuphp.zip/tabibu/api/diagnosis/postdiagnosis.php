<?php

require_once("../config/config.php");

$disease = $_POST["disease"];
$description = $_POST["description"];
$date = $_POST["date"];
$weight = $_POST["weight"];
$temp = $_POST["temp"];
$pulse = $_POST["pulse"];
$pressure = $_POST["pressure"];
$symptoms = $_POST["symptoms"];
$medicine = $_POST["medicine"];
$prescription = $_POST["prescription"];
$treatmentinfo = $_POST["treatmentinfo"];
$status = $_POST["status"];
$dr_id = $_POST["dr_id"];
$pt_id = $_POST["pt_id"];

    $query = "INSERT INTO medrecords (recordid,disease,description,date,weight,temp,pulse,pressure,symptoms,medicine,prescription,treatmentinfo,status,dr_id,pt_id) VALUES (null, '$disease', '$description', '$date', '$weight', '$temp', '$pulse', '$pressure', '$symptoms', '$medicine', '$prescription', '$treatmentinfo', '$status', '$dr_id', '$pt_id')";
    $res = mysqli_query($conn, $query);

    if($res){
            echo json_encode("success");
    }else{
        echo json_encode("error");
    }

?>