<?php

require_once("../config/config.php");

$apptid = $_POST["apptid"];
//$apptid ="8";

//first check if account exists

$query = "SELECT * FROM appointmentlist WHERE apptid = '".$apptid."'";
$res = mysqli_query($conn, $query);
$data = mysqli_fetch_array($res);
$count = mysqli_num_rows($res);

// data[0] = apptid, data[1] = ptid, data[2] = docid, data[3] = date
// data[4] = time, data [5] = location, data[6] = reason, data[7] = status
// data[8] = drname, data[9] = ptname
if ($count == 1){
    echo json_encode([$data['0'],$data['1'],$data['2'],$data['3'],$data['4'],$data['5'],$data['6'],$data['7'],$data['8'],$data['9']]);
}else{
    echo json_encode("inexistent");
}
?>