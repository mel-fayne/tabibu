<?php

require_once("../config/config.php");

$apptid = $_POST["apptid"];
//$apptid = "1";

$time = $_POST["time"];
$status = "Confirmed";

    $query = "UPDATE appointmentlist set status = 'Confirmed', time = '".$time."' WHERE apptid ='".$apptid."'";
    $res = mysqli_query($conn, $query);

    if($res){
            echo json_encode("success");
    }else{
        echo json_encode("error");
    }

?>