<?php

require_once("../config/config.php");

$apptid = $_POST["apptid"];
//$apptid = "1";
$status = "Done";


    $query = "UPDATE appointmentlist set status='".$status."' WHERE apptid ='".$apptid."'";
    $res = mysqli_query($conn, $query);

    if($res){
            echo json_encode("success");
    }else{
        echo json_encode("error");
    }

?>