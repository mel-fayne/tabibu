<?php

require_once("../config/config.php");

$patientid = $_POST["patientid"];
$doctorid = $_POST["doctorid"];
$date = $_POST["date"];
$location = $_POST["location"];
$reason = $_POST["reason"];

    $query = "INSERT INTO appointments (apptid,patientid,doctorid,date,time,location,reason) VALUES (null, '$patientid', '$doctorid', '$date', null, '$location', '$reason')";
    $res = mysqli_query($conn, $query);

    if($res){
            echo json_encode("success");
    }else{
        echo json_encode("error");
    }

?>